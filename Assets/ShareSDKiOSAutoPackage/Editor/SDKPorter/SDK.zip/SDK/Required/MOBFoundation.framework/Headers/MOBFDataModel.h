//
//  MOBFDataModel.h
//  MOBFoundation
//
//  Created by 冯鸿杰 on 17/2/15.
//  Copyright © 2017年 MOB. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IMOBFDataModel.h"

/**
 数据模型
 */
@interface MOBFDataModel : NSObject <IMOBFDataModel,
                                     NSCoding>

@end
